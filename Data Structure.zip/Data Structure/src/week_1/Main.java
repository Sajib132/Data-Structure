package week_1;

public class Main {

	public static void main(String[] args) {
		Stack s=new Stack();
		s.push(45);
		s.push(2);
		s.pop();
		s.push(5);
		

	}

}
