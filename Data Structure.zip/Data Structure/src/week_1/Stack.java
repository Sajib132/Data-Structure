package week_1;

public class Stack {	
int ar[]=new int[100];
int top=-1;
boolean isEmpty() {
	return(top<0);
}
boolean push(int x) {
	if(top>=100-1) {
		System.out.println("Stack is Overflow");
		return false;
	}
	else {
		ar[++top]=x;
		System.out.println(x + " Pushed into stack");
		return true;
	}
}
	int pop() {
		if(top<0) {
			System.out.println("Stack Underflow");
			return 0;
		}
		else {
			int x=ar[top--];
			System.out.println(x + " Popped from the stack");
			return x;
		}
	}
int peek() {
	if(top<0) {
		System.out.println("Stack Underflow");
		return 0;
	}
	else {
		int x=ar[top];
		return x;
	}
}
}
